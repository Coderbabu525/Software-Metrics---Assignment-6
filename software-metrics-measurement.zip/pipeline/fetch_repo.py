import os
import subprocess

REPO_URL = "https://github.com/fastapi/fastapi"
CLONE_DIR = "fastapi_repo"

def fetch_repo():
    if os.path.exists(CLONE_DIR):
        subprocess.run(["rm", "-rf", CLONE_DIR])

    subprocess.run(["git", "clone", REPO_URL, CLONE_DIR])

    return CLONE_DIR