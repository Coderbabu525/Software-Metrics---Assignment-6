import subprocess
from collections import defaultdict
from datetime import datetime

REPO_PATH = "fastapi_repo"


def get_git_data(days=30):
    """
    Research-grade Git mining:
    Only analyze last N days (not full history)
    """

    # Get commits with metadata
    cmd = [
        "git",
        "-C", REPO_PATH,
        "log",
        f"--since={days}.days",
        "--pretty=format:%H|%an|%ad",
        "--date=iso",
        "--name-only"
    ]

    output = subprocess.check_output(cmd, text=True, errors="ignore")

    commits = []
    file_changes = defaultdict(list)
    devs = defaultdict(int)

    current_commit = None

    for line in output.split("\n"):

        line = line.strip()

        if "|" in line:
            parts = line.split("|")
            current_commit = parts[0]
            author = parts[1]

            commits.append(current_commit)
            devs[author] += 1
            continue

        if line == "" or current_commit is None:
            continue

        file_changes[current_commit].append(line)

    return commits, file_changes, devs