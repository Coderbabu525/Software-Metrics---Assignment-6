import pandas as pd
from datetime import datetime

from pipeline.git_data import get_git_data
from metrics import stability, change_frequency, ownership, dev_activity, coupling, complexity, hotspot


def run():

    commits, file_changes, devs = get_git_data(days=30)

    row = {
        "date": datetime.now().strftime("%Y-%m-%d %H:%M"),

        "stability": stability.compute(file_changes),
        "change_frequency": change_frequency.compute(commits),
        "ownership": ownership.compute(devs),
        "dev_activity_count": len(devs),
        "coupling": coupling.compute(file_changes),
        "complexity": complexity.compute("fastapi_repo"),

        "hotspot_index": hotspot.compute(file_changes),
    }

    file = "data/metrics.csv"

    try:
        df = pd.read_csv(file)
        df = pd.concat([df, pd.DataFrame([row])])
    except:
        df = pd.DataFrame([row])

    df.to_csv(file, index=False)


if __name__ == "__main__":
    run()