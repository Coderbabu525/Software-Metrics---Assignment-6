from playwright.sync_api import sync_playwright
import os
from datetime import datetime

URL = "http://localhost:8501"
OUTPUT_DIR = "screenshots"

def take_screenshot():

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    date = datetime.now().strftime("%Y-%m-%d")
    path = f"{OUTPUT_DIR}/{date}.png"
    latest = f"{OUTPUT_DIR}/dashboard_latest.png"

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()

        page.goto(URL)

        page.wait_for_timeout(5000)  # allow dashboard to load

        page.screenshot(path=path, full_page=True)
        page.screenshot(path=latest, full_page=True)

        browser.close()

    print("Screenshot saved:", path)