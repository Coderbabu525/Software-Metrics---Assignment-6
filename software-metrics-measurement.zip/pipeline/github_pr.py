from github import Github

REPO_NAME = "tiangolo/fastapi"

def get_pr_data(token):

    g = Github(token)
    repo = g.get_repo(REPO_NAME)

    pr_sizes = []

    for pr in repo.get_pulls(state="all"):

        files = pr.get_files()

        file_count = 0
        additions = 0
        deletions = 0

        for f in files:
            file_count += 1
            additions += f.additions
            deletions += f.deletions

        pr_sizes.append({
            "pr_number": pr.number,
            "files": file_count,
            "additions": additions,
            "deletions": deletions,
            "total_changes": additions + deletions
        })

    return pr_sizes