def compute(merge_time, commit_time):
    return (merge_time - commit_time).total_seconds() / 3600