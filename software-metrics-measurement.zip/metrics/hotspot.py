from collections import defaultdict

def compute(file_changes):

    freq = defaultdict(int)

    for files in file_changes.values():
        for f in files:
            freq[f] += 1

    if not freq:
        return 0

    top = max(freq.values())
    total = sum(freq.values())

    return top / total