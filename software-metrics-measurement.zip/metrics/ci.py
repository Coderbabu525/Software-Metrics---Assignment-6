def compute(failed, total):
    if total == 0:
        return 0
    return failed / total