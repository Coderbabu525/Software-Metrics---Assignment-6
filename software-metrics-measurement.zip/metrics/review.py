def compute(comments, hours):
    if hours == 0:
        return 0
    return comments / hours