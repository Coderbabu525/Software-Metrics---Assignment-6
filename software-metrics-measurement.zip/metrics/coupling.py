from collections import defaultdict

def compute(file_changes):

    pairs = 0
    commits = len(file_changes)

    for files in file_changes.values():
        n = len(set(files))
        pairs += n * (n - 1) / 2

    if commits == 0:
        return 0

    return pairs / commits