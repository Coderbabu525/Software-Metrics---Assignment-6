def compute(commits):
    return len(commits)