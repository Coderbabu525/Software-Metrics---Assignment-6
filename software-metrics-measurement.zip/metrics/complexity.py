import ast
import os

def compute(repo_path):

    total = 0

    for root, _, files in os.walk(repo_path):
        for f in files:
            if not f.endswith(".py"):
                continue

            path = os.path.join(root, f)

            try:
                tree = ast.parse(open(path, encoding="utf-8").read())
            except:
                continue

            for node in ast.walk(tree):
                if isinstance(node, (ast.If, ast.For, ast.While, ast.Try)):
                    total += 1

    return total