def compute(file_changes):

    all_files = set()
    changed = set()

    for files in file_changes.values():
        for f in files:
            all_files.add(f)
            changed.add(f)

    if len(all_files) == 0:
        return 0

    return len(changed) / len(all_files)