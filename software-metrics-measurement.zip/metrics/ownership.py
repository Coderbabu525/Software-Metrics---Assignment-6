def compute(devs):
    total = sum(devs.values())
    if total == 0:
        return 0

    return max(devs.values()) / total