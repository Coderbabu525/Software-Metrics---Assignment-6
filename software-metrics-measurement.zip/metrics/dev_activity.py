def compute(devs):
    total = sum(devs.values())
    if total == 0:
        return {}

    return {d: c / total for d, c in devs.items()}