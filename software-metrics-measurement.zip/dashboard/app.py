import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="Software Metrics Dashboard", layout="wide")

# Load data
df = pd.read_csv("data/metrics.csv")

st.title("📊 Software Metrics Measurement Dashboard")

# ---------------------------
# KPI SECTION
# ---------------------------
st.header("📌 Latest Metrics")

latest = df.iloc[-1]

col1, col2, col3, col4 = st.columns(4)

col1.metric("Stability", round(latest["stability"], 3))
col2.metric("Change Frequency", latest["change_frequency"])
col3.metric("Ownership", round(latest["ownership"], 3))
col4.metric("Hotspot Index", round(latest["hotspot_index"], 3))

st.markdown("---")

# ---------------------------
# TREND CHARTS
# ---------------------------
st.header("📈 Metric Trends Over Time")

metrics_to_plot = [
    "stability",
    "change_frequency",
    "ownership",
    "coupling",
    "complexity",
    "hotspot_index"
]

for metric in metrics_to_plot:
    fig = px.line(df, x="date", y=metric, markers=True, title=metric)
    st.plotly_chart(fig, use_container_width=True)

st.markdown("---")

# ---------------------------
# RAW DATA
# ---------------------------
st.header("📋 Raw Data")

st.dataframe(df)